import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;



public class Solution 
{

    public static void main(String[] args) 
    {
            String instr,substr=null;
            boolean found = false;
            
            int counter;
           // System.out.println("Enter the input String");
            Scanner scanner  = new Scanner(System.in);
            instr = scanner.nextLine();
            
           //Length of the string
            int strlen = instr.length();
            
            //If it is a single character then print the same output
            if(strlen==1)
                System.out.println(instr);
            else
            {
                //Check if the string is Odd length or Even length
                if(strlen%2 == 1)
                {
                     counter = strlen/2;
                    strlen = counter + 1;
                }
                else
                {
                    counter = strlen/2;
                    strlen = counter;
                }
            
                for(; counter >= 1; counter--,strlen++)
                {
                    //Get the substring
                    substr = instr.substring(0,counter);
                
                    if(substr.equals(instr.substring(strlen)))
                    {
                        found = true;  // Found the longest substring present at start and end
                         break;
                    }
                }
               
                if(found)
                     System.out.println(substr);
                else
                   System.out.println("No matching substring in the input");
            }
    }
}